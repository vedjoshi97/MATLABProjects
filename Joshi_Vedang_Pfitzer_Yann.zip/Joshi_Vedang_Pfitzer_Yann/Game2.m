function Game2(N,vBuiltIn)
%function that runs the main loop that maneuvers object through maze and
%loads & reads matrix that later is plotted as the maze
%Establishing figure settings
ss = get(0,'ScreenSize');
set(gcf,'Position',ss);
set(gcf,'Color',[.2 .2 .2]);

%calls nested function that loads map built using a 100x100 matrix
createFigure

set (gcf,'menubar','none');

%vector that is made up of values from first column of the matrix
v=MatrixN{1,N}(:,1);
ii=1;
%loop that creates a smaller array of matrix indeces that are composed of
%the region where the can is initially placed via the following code
for kk=1:length(v)
    if v(kk)==1
        startingRegion(ii)=kk;
        ii=ii+1;
    end
end
%y-value of soda can's center point
objCenterPointY=((startingRegion(end)-startingRegion(1))/2)+ startingRegion(1);
%dimensions of the soda can
w=4;
l=2;
xi=.5+w/2;
yi=1+l/2;
yi=objCenterPointY + 1;

%importing png of soda can
[colData,~,aData] = imread('MtDew.png');
hold on
can = imshow(colData);
set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2]);
%setting A-data
set(can,'AlphaData',aData); 
canSpeedX=0;
canSpeedY=0;

[m,n]=size(MatrixN{1,N});
%capturing keypressfunction
set(gcf,'KeyPressFcn',@MyKeyDown);
dt=.1;

%main loop that maneuvers the can within the constraints of the maze and
%boundaries of the matrix
while MatrixN{1,N}(round(yi),round(xi))==1 && MatrixN{1,N}(round(yi),round(xi)+w/2)==1 ...
    && MatrixN{1,N}(round(yi)- l/2,round(xi))==1 ...
    && MatrixN{1,N}(round(yi),round(xi)-w/2)==1 && ... 
    MatrixN{1,N}(round(yi)+ l/2,round(xi))==1 && ...
    round(xi)<n && round(yi)<m && round(xi)>1 && round(yi)>1
    xi = xi + canSpeedX*dt;
    yi = yi + canSpeedY*dt;

    set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2])

    drawnow
end
%if while loop breaks out, then the matrix value at the index could be
%either a 0 (meaning you lost) or 2(meaning you move on to the next level)


if MatrixN{1,N}(round(yi),round(xi))==2 || MatrixN{1,N}(round(yi),round(xi)+w/2)==2 ...
    || MatrixN{1,N}(round(yi)- l/2,round(xi))==2 ...
    || MatrixN{1,N}(round(yi),round(xi)-w/2)==2 || ... 
    MatrixN{1,N}(round(yi)+ l/2,round(xi))==2
    %increments level by adding 1 to N
    N=N+1;
    %recursively calls main function
    Game2(N,vBuiltIn)
elseif MatrixN{1,N}(round(yi),round(xi))==0 || MatrixN{1,N}(round(yi),round(xi)+w/2)==0 ...
    || MatrixN{1,N}(round(yi)- l/2,round(xi))==0 ...
    || MatrixN{1,N}(round(yi),round(xi)-w/2)==0 || ... 
    MatrixN{1,N}(round(yi)+ l/2,round(xi))==0 || ...
    round(xi)>=n || round(yi)<=m || xi==.5 || round(yi)==.5
    close all   
    %goes to a page that is designated when game is lost
    LosingPage
end

%nested function that takes in keyboard presses, and changes velocity
%control

    function MyKeyDown(hObject,event,handles)
        whichKey = event.Key;
        switch whichKey
            case 'uparrow' 
                canSpeedY=-vBuiltIn;
                canSpeedX=0;
                
            case 'downarrow'
                canSpeedY=vBuiltIn;
                canSpeedX=0;
               
            case 'leftarrow'
                canSpeedX=-vBuiltIn;
                canSpeedY=0;  
            case 'rightarrow' 
                canSpeedX=vBuiltIn;
                canSpeedY=0;
            case 'd'
                canSpeedX=vBuiltIn;
                canSpeedY=0;
            case 'w'
                canSpeedY=-vBuiltIn;
                canSpeedX=0;
            case 'a'
                canSpeedX=-vBuiltIn;
                canSpeedY=0;  
            case 's'
                canSpeedY=vBuiltIn;
                canSpeedX=0;
                
        end
        
    end

        
        


function createFigure 
%7 established maps that increase in complexity
Lvl1 = zeros(100);
Lvl1(40:50,1:40) = 1;
Lvl1(40:85,40:50) = 1;
Lvl1(85:95,40:80) = 1;
Lvl1(20:85,70:80) = 1;
Lvl1(12:20,20:80) = 1;
Lvl1(12:20,20:23) = 2;


Lvl2 = zeros(100);
Lvl2(10:20,1:80) = 1;
Lvl2(10:80,80:90) = 1;
Lvl2(80:90,30:90) = 1;
Lvl2(50:90,22:30) = 1;
Lvl2(42:50,22:60) = 1;
Lvl2(50:70,52:60) = 1;
Lvl2(66:73,38:60) = 1;
Lvl2(66:73,38:40) = 2;

Lvl3 = zeros(100);
Lvl3(75:90,1:15) = 1;
Lvl3(67:82,15:30) = 1;
Lvl3(59:74,30:45) = 1;
Lvl3(10:59,34:41) = 1;
Lvl3(10:20,41:80) = 1;
Lvl3(20:80,60:80) = 1;
Lvl3(21:25,60:71) = 0;
Lvl3(36:40,69:80) = 0;
Lvl3(51:55,60:71) = 0;
Lvl3(66:69,68:71) = 0;
Lvl3(80:95,60:67) = 1;
Lvl3(93:95,60:67) = 2;

 
Lvl4 = zeros(100);
Lvl4(80:98,1:8) = 1;
Lvl4(80:87,8:30) = 1;
Lvl4(50:87,30:37) = 1;
Lvl4(43:50,5:37) = 1;
Lvl4(15:43,5:15) = 1;
Lvl4(15:22,15:80) = 1;
Lvl4(22:45,72:80) = 1;
Lvl4(45:52,50:80) = 1;
Lvl4(52:80,50:57) = 1;
Lvl4(80:82,50:57) = 2;
 
 
 
Lvl5 = zeros(100);
Lvl5(10:25,1:15) = 1;
Lvl5(17:32,15:30) = 1;
Lvl5(24:39,30:45) = 1;
Lvl5(31:46,45:60) = 1;
Lvl5(46:70,51:60) = 1;
Lvl5(70:80,15:60) = 1;
Lvl5(60:70,15:25) = 1;
Lvl5(58:60,15:25) = 2;
 
 
 
Lvl6 = zeros(100);
Lvl6(80:87,1:15) = 1;
Lvl6(15:87,15:23) = 1;
Lvl6(15:23,15:90) = 1;
Lvl6(15:87,30:37) = 1;
Lvl6(73:80,48:90) = 1;
Lvl6(15:80,48:55) = 1;
Lvl6(15:80,83:90) = 1;
Lvl6(80:87,83:90) = 1;
Lvl6(87:93,30:90) = 1;
Lvl6(15:80,48:55) = 1;
Lvl6(87:93,30:37) = 2;
 
 
Lvl7 = zeros(100);
Lvl7(75:90,1:15) = 1;
Lvl7(67:82,15:30) = 1;
Lvl7(59:74,30:45) = 1;
Lvl7(10:59,34:41) = 1;
Lvl7(10:20,41:80) = 1;
Lvl7(20:80,60:80) = 1;
Lvl7(21:25,60:71) = 0;
Lvl7(36:40,69:80) = 0;
Lvl7(51:55,60:71) = 0;
Lvl7(66:69,68:71) = 0;
Lvl7(80:95,60:67) = 1;
Lvl7(93:95,60:67) = 2;
 
 
MatrixN{1,1}=Lvl1;
MatrixN{1,2}=Lvl2;
MatrixN{1,3}=Lvl3;
MatrixN{1,4}=Lvl4;
MatrixN{1,5}=Lvl5;
MatrixN{1,6}=Lvl6;
MatrixN{1,7}=Lvl7;
 
imagesc(MatrixN{1,N});
colormap(gray)
axis off
axis equal

end

end

