function LevelsPage
%function that loads a page with several buttons 
%the user can click on these buttons to go to whichsoever level he or she
%chooses
figure
%establishes figures settings
[col11Data,~,a11Data] = imread('button11.png');
can4 = imshow(col11Data);
gs = get(0,'ScreenSize');
set(gcf,'Position',gs);
set (gcf,'menubar','none');
set(gcf, 'Color', 'k');
%buttons that call nested functions that loads levels 1 to 7
btn1 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Level 1','Position', [0.2 0.7 0.15 0.15],...
        'Callback', @L1,'FontSize',24);
btn2 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Level 2','Position', [0.2 0.5 0.15 0.15],...
        'Callback', @L2,'FontSize',24);
btn3= uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Level 3','Position', [0.2 0.3 0.15 0.15],...
        'Callback', @L3,'FontSize',24);
btn4= uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Level 4','Position', [0.45 0.7 0.15 0.15],...
        'Callback', @L4,'FontSize',24);
btn5 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Level 5','Position', [0.45 0.5 0.15 0.15],...
        'Callback', @L5,'FontSize',24);
btn6 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Level 6','Position', [0.45 0.3 0.15 0.15],...
        'Callback', @L6,'FontSize',24);
btn7= uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Level 7','Position', [0.7 0.7 0.15 0.15],...
        'Callback', @L7,'FontSize',24);
    
    %nested functions that each call a different level (indirectly by first
    %calling computationTimeLoader2 which takes in a level number as an
    %input)
    function L1(hObj,event)
        close all
        ComputationTimeLoader2(1)
    end
    function L2(hObj,event)
        close all
        ComputationTimeLoader2(2)
    end
    function L3(hObj,event)
        close all
        ComputationTimeLoader2(3)
    end
    function L4(hObj,event)
        close all
        ComputationTimeLoader2(4)
    end
    function L5(hObj,event)
        close all
        ComputationTimeLoader2(5)
    end
    function L6(hObj,event)
        close all
        ComputationTimeLoader2(6)
    end
    function L7(hObj,event)
        close all
        ComputationTimeLoader2(7)
    end
end
