function WinningPage
%page that displays when user beat his/her own map
close all
fig3 = figure
set (gcf,'menubar','none');
gs = get(0,'ScreenSize');

      
%establishing basic figure settings and import large cartoon png      
set(fig3, 'menubar','none');
movegui(fig3,'center')
[colData,~,aData] = imread('grahamcartoon.png');

can2 = imshow(colData);

set(can2,'AlphaData',aData); 
set(gcf,'Position',gs);
 
hold on
set(fig3, 'Color', 'k')
%buttons that will call nested functions that query the user to either
%create another map or go back to main menu
btn10 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Back to menu',...
        'Position', [0.01 0.5 0.30 0.25],...
        'Callback', @resetMenu,'FontSize',35,'BackgroundColor','g');
btn11 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Give Graham more Dew!','Position', [0.67 0.5 0.30 0.25],...
        'Callback', @backToDesignGame,'FontSize',30,'BackgroundColor','g');
    
    function resetMenu (hObj,event)
        close all
        IntroMenu
    end
    function backToDesignGame (hObj,event)
        close all
        makeOwnMap
    end
end