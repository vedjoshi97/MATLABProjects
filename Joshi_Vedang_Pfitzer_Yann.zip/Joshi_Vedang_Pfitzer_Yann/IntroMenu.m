function IntroMenu
%This is the function that should be run to initialize the entire game
%no other function in this file should be separately run
%establishing figure setting
gs = get(0,'ScreenSize');
fig3 = figure
set (gcf,'menubar','none');
movegui(fig3,'center')
%Background is Mountain Dew themed
[colData,~,aData] = imread('MTNDewIntro.png'); 

can2 = imshow(colData);

set(can2,'AlphaData',aData); 
set(gcf,'Position',gs);
 
hold on
set(fig3, 'Color', 'k')

%Establishing pushbuttons using uicontrol
btn8 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'New Game','Position', [0.8 0.3 0.15 0.15],...
        'Callback', @gameTwo,'FontSize',24);
btn9 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Design Game','Position', [0.8 0.5 0.15 0.15],...
        'Callback', @gameOne,'FontSize',24);
btn10= uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Instructions','Position', [0.8 0.1 0.15 0.15],...
        'Callback', @gameInst,'FontSize',24);
btn11= uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Load Level','Position', [0.8 0.7 0.15 0.15],...
        'Callback', @resumeLvl,'FontSize',24);
    
%Setting background colors for buttons    
Pos8=get(btn8,'Position');
[colData,~,a8Data] = imread('button8.png');
can1 = imshow(colData);
set(can1,'XData',[Pos8(1) Pos8(2)],'YData',[Pos8(3) Pos8(4)])

set(btn8,'CData',colData);

Pos9=get(btn9,'Position');
[col9Data,~,a9Data] = imread('button9.png');
can2 = imshow(colData);
set(can2,'XData',[Pos9(1) Pos9(2)],'YData',[Pos9(3) Pos9(4)])

set(btn9,'CData',col9Data);

Pos10=get(btn10,'Position');
[col10Data,~,a10Data] = imread('button10.png');
can3 = imshow(colData);
set(can3,'XData',[Pos10(1) Pos10(2)],'YData',[Pos10(3) Pos10(4)])
set(btn10,'CData',col10Data);

Pos11=get(btn11,'Position');
[col11Data,~,a11Data] = imread('button11.png');
can4 = imshow(colData);
set(can4,'XData',[Pos11(1) Pos11(2)],'YData',[Pos11(3) Pos11(4)])
set(btn11,'CData',col11Data);


%nested function that calls loading page for game    
    function gameTwo(hObj,event)
        close all
        ComputationTimeLoader
    end
%nested function that calls the make-your-own map algorithm
    function gameOne(hObj,event)
        close all
        makeOwnMap
    end
%nested function that goes to the basic instructions page 
%please read before playing initially!
    function gameInst(hObj,event)
        close all
        gameInstructions
    end
%nested function that goes to a loading levels page
    function resumeLvl(hObj,event)
        close all
        LevelsPage
    end
end