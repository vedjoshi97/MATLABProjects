function map= makeOwnMap
    
    % Set intial figure Properties
    ss = get(0,'ScreenSize');
    fig = figure('WindowButtonDownFcn',@initSquare,...
        'WindowButtonUpFcn',@changeValueMatrix,...
        'WindowButtonMotionFcn',@dragSquare,'Position',ss.*0.8); 
    axes('Position',[0.2,0.1,0.75,0.85])
    movegui(fig,'center')
    set (gcf,'menubar','none');
    set(gcf,'Position',ss);
    
    % Plots zeros (all black)
    map = zeros(100);
    map(40:45,1:2)=1;
    imagesc(map)
    colormap(gray)
    axis off
    h = [];
    t = title('click and hold down to drag pieces into place')
    t.Color = 'red'
    t.FontSize = 15
    
    % Creates the buttons for the color of the rectangle you want to plot
    
    btn1 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Click to add Path','Position', [0.03 0.8 0.15 0.15],...
        'Callback', @changeCto1,'BackgroundColor', [1 1 1],'FontSize',18);
    
    btn2 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Click to add Wall','Position', [0.03 0.6 0.15 0.15],...
        'Callback', @changeCto0,'BackgroundColor', [0 0 0],...
        'ForegroundColor', [1 1 1],'FontSize',18);
    
    btn3 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Click to add final square','Position', [0.03 0.4 0.15 0.15],...
        'Callback', @changeCto2,'BackgroundColor',...
        [0.6 0.6 0.6],'FontSize',14);
    
    % Button 4 erases the map and lets user start over
    btn4 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Erase all','Position', [0.85 0.01 0.1 0.08],...
        'Callback', @eraseAll,'ForegroundColor', [1 0 0],'FontSize',14);
    
    % Button 5 enables user to save his created map so he can play it
    btn5 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Complete?','Position', [0.03 0.1 0.1 0.1],...
        'Callback', @SaveMatrix,'FontSize',14);
    
    btn6= uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'play','Position', [0.03 0.2 0.1 0.1],...
        'Callback', @playGame,'FontSize',14);
    
    
    % Assignes the value of the matrix for each color depending on which button
    % was pressed.
    c = 1;
    function changeCto1(hObj,event)
        c = 1
    end
    
    function changeCto0(hObj,event)
        c = 0
    end
    
    function changeCto2(hObj,event)
        c = 2
    end
    
    % Creates just the initial visual preview of the rectangle that follows cursor
    function initSquare(varargin)
        
        pos = get(gca,'CurrentPoint');
        xLoc = pos(1,1);
        yLoc = pos(1,2);
        h = rectangle('Position', [xLoc-3, yLoc-3,5,5],'FaceColor', [0 0 1]);
    end
    
    
    % Every time the mouse is clicked matrix values are switched
    function changeValueMatrix(~,~)
        
        h = [];
        pos = get(gca,'CurrentPoint')
        pos = pos(1,1:2);
        MatPos = round(pos);
        if MatPos(1)<=3
            MatPos(1) = 3;
        end
        if MatPos(2)<=3
            MatPos(2) = 3;
        end
        if MatPos(1)>=98
            MatPos(1) = 98;
        end
        if MatPos(2)>=98
            MatPos(2) = 98;
        end
       
        
        map(MatPos(2),MatPos(1)) = c;
        map((MatPos(2)+1),(MatPos(1)+1)) = c;
        map((MatPos(2)+2),(MatPos(1)+1)) = c;
        map((MatPos(2)+1),(MatPos(1)+2)) = c;
        map((MatPos(2)+2),(MatPos(1)+1)) = c;
        map((MatPos(2)+2),(MatPos(1)+2)) = c;
        map((MatPos(2)),(MatPos(1)+2)) = c;
        map((MatPos(2)),(MatPos(1)+1)) = c;
        map((MatPos(2)+2),(MatPos(1))) = c;
        map((MatPos(2)+1),(MatPos(1))) = c;
        
        map((MatPos(2)-1),(MatPos(1)-1)) = c;
        map((MatPos(2)-2),(MatPos(1)-1)) = c;
        map((MatPos(2)-1),(MatPos(1)-2)) = c;
        map((MatPos(2)-2),(MatPos(1)-1)) = c;
        map((MatPos(2)-2),(MatPos(1)-2)) = c;
        map((MatPos(2)),(MatPos(1)-2)) = c;
        map((MatPos(2)),(MatPos(1)-1)) = c;
        map((MatPos(2)-2),(MatPos(1))) = c;
        map((MatPos(2)-1),(MatPos(1))) = c;
        
        map((MatPos(2)-1),(MatPos(1)+1)) = c;
        map((MatPos(2)-2),(MatPos(1)+1)) = c;
        map((MatPos(2)-1),(MatPos(1)+2)) = c;
        map((MatPos(2)-2),(MatPos(1)+2)) = c;
        map((MatPos(2)+2),(MatPos(1)-1)) = c;
        map((MatPos(2)+1),(MatPos(1))) = c;
        map((MatPos(2)+1),(MatPos(1)-1)) = c;
        map((MatPos(2)+1),(MatPos(1)-2)) = c;
        map((MatPos(2)+1),(MatPos(1)-2)) = c;
        map((MatPos(2)+2),(MatPos(1)-2)) = c;
        imagesc(map)
        colormap(gray)
        axis off
        t = title('click and hold down to drag pieces into place')
        t.Color = 'red'
        t.FontSize = 15
    end
    function SaveMatrix(hObj,event)
        save('UserCreatedMatrix.mat','map')
    end
    
    
    function dragSquare(varargin)
        if ~isempty(h)
            pos = get(gca,'CurrentPoint');
            xLoc = pos(1,1);
            yLoc = pos(1,2);
            set(h,'Position', [xLoc-3, yLoc-3,5,5])
        end
    end
    function eraseAll(hObj,event)
        map = zeros(100);
        imagesc(map)
        colormap(gray)
        axis off
    end

    function playGame(hObj,event)
        close all
        ComputationTimeLoader3(map)
    end
end