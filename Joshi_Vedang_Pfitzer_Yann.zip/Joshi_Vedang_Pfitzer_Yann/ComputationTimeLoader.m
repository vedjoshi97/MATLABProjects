function vBuiltIn = ComputationTimeLoader
%(slick) function that outputs a scaled velocity based on time to perform
%computation and graphics animation (tested on various computers)
%because it runs an animation while doing this, it serves as a good loading
%page before a level begins


    tic %initializes timer
    %establishes figure settings
    bs = get(0,'ScreenSize');
    fig2 = figure('Position',bs);
    set(fig2, 'menubar','none');
    set(fig2,'Color',[0.2 0.2 0.2])
    StartMap = zeros(100);
    StartMap(30:40,1:40) = 1;
    StartMap(30:80,40:50) = 1;
    StartMap(70:80,50:100) = 1;
    StartMap(70:80,95:100) = 2;
    imagesc(StartMap)
    colormap(gray)
    axis off

%initializing can position
objCenterPointY= 35; 
w=8;
l=4;
xi=.5+w/2;
yi=1+l/2;
yi=objCenterPointY + 1;

%importing soda can png
[colData,~,aData] = imread('MtDew.png');
hold on
can = imshow(colData);
set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2]);
set(can,'AlphaData',aData); 
canSpeedX=7;
canSpeedY=0;
[m,n]=size(StartMap)
set(gcf,'KeyPressFcn',@MyKeyDown);
dt=.1;
%Text that user can read as animation plays out
text(102,15,'LOADING...','Color',[0 1 0],'FontSize', 18)
text(102,20,'Maneuver the can through the maze','Color',[0 1 0],'FontSize', 18)
text(102,25,'without touching the edges!!','Color',[0 1 0],'FontSize', 18)
text(-45,15,'CAN','Color',[0 1 0],'FontSize', 50)
text(-40,25,'YOU','Color',[1 0 0],'FontSize', 50)
text(-45,35,'DEW','Color',[0 1 0],'FontSize', 50)
text(-40,45,'IT?!?','Color',[1 0 0],'FontSize', 50)
%while loop that runs through animation
while round(xi)<n 
    xi = xi + canSpeedX*dt;
    yi = yi + canSpeedY*dt;

    set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2])

    %can changing direction to follow the path of the maze (can moves down)
    if round(xi) == 45
        canSpeedX=0;
        canSpeedY=5;
    xi = xi + canSpeedX*dt;
    yi = yi + canSpeedY*dt;
        set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2]);
    end
    %changes direction again-- (can moves to the right)
    if round(yi) == 75
        canSpeedX=5;
        canSpeedY=0;
    xi = xi + canSpeedX*dt;
    yi = yi + canSpeedY*dt;
        set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2]);
    end
      drawnow  
    if StartMap(round(yi),round(xi))==2
        t = toc;
    end
end
close all

%outputs a velocity that scales to almost all computers based on a linear
%fit calculated experimentally and mathematically
vBuiltIn=(7.03*t/2.6720)+.030
Game2(1,vBuiltIn)