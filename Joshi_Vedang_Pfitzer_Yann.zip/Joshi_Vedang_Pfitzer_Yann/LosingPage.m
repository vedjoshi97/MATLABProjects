function LosingPage
%function that loads page designated for when game is lost
cla
[col11Data,~,a11Data] = imread('donaldT.png');
can4 = imshow(col11Data);
gs = get(0,'ScreenSize');
set(gcf,'Position',gs);
set (gcf,'menubar','none');
set(gcf, 'Color', 'k');
%buttons that call nested functions that either load main menu or quit the
%entirety of the game
btn1 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Back to Menu','Position', [0.1 0.3 0.10 0.10],...
        'Callback', @resetLevel,'FontSize',16);
btn2 = uicontrol('Style', 'pushbutton','Units','Normalized',...
        'String', 'Quit Out','Position', [0.8 0.3 0.10 0.10],...
        'Callback', @quitAll,'FontSize',16);
 
 
    
    function resetLevel(hObject,event)
        close all
        %going back to main menu for another shot
        IntroMenu
    end 

    function quitAll(hObject,event)
        %closing all figure windows in order to quit the game
        close all
    end
    
end