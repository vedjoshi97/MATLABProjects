function Game1(map,vBuiltIn)
%function that runs the main loop that maneuvers object through map that was created earlier and
%loads & reads the created matrix that later is plotted as the maze
%Establishing figure settings
%different from Game2 in the sense that it takes in a user made map and
%runs on a slightly different algortithm
imagesc(map);
colormap(gray)
axis off
axis equal
ss = get(0,'ScreenSize');
set(gcf,'Position',ss);
set(gcf,'Color',[.2 .2 .2]);
load('UserCreatedMatrix.mat')
set (gcf,'menubar','none');
v=map(:,1);
ii=1;
%loop that finds starting position of can based on following code
for kk=1:length(v)
    if v(kk)==1
        startingRegion(ii)=kk;
        ii=ii+1;
    end
end

objCenterPointY=((startingRegion(end)-startingRegion(1))/2)+ startingRegion(1);
w=4;
l=2;
xi=.5+w/2;
yi=1+l/2;
yi=objCenterPointY + 1;
%importing can
[colData,~,aData] = imread('MtDew.png');
hold on
can = imshow(colData);
set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2]);
set(can,'AlphaData',aData); 
canSpeedX=0;
canSpeedY=0;
[m,n]=size(map);
set(gcf,'KeyPressFcn',@MyKeyDown);
dt=.1;

%main loop that maneuvers the can within the constraints of the maze and
%boundaries of the matrix
while map(round(yi),round(xi))==1 & map(round(yi),round(xi)+w/2)==1....
    & map(round(yi)- l/2,round(xi))==1 & map(round(yi),round(xi)-w/2)==1 ...
    & map(round(yi)+ l/2,round(xi))==1 & round(xi)<n & round(yi)<m & ...
    round(xi)>0 & round(yi)>0 
    xi = xi + canSpeedX*dt;
    yi = yi + canSpeedY*dt;

    set(can,'XData',[xi-w/2 xi+w/2],'YData',[yi-l/2 yi+l/2])

    drawnow
end
if map(round(yi),round(xi))==2 || map(round(yi),round(xi)+w/2)==2 ...
    || map(round(yi)- l/2,round(xi))==2 ...
    || map(round(yi),round(xi)-w/2)==2 || ... 
    map(round(yi)+ l/2,round(xi))==2
    close all
    WinningPage
elseif map(round(yi),round(xi))==0 || map(round(yi),round(xi)+w/2)==0 ...
    || map(round(yi)- l/2,round(xi))==0 ...
    || map(round(yi),round(xi)-w/2)==0 || ... 
    map(round(yi)+ l/2,round(xi))==0 || ...
    round(xi)>=n || round(yi)<=m || xi==.5 || round(yi)==.5
    close all
    LosingPage
end


    function MyKeyDown(hObject,event,handles)
        whichKey = event.Key;
        switch whichKey
            case 'uparrow'
                canSpeedY=-vBuiltIn;
                canSpeedX=0;
                
            case 'downarrow'
                canSpeedY=vBuiltIn;
                canSpeedX=0;
               
            case 'leftarrow'
                canSpeedX=-vBuiltIn;
                canSpeedY=0;  
            case 'rightarrow'
                canSpeedX=vBuiltIn;
                canSpeedY=0;
            case 'd'
                canSpeedX=vBuiltIn;
                canSpeedY=0;
            case 'w'
                canSpeedY=-vBuiltIn;
                canSpeedX=0;
            case 'a'
                canSpeedX=-vBuiltIn;
                canSpeedY=0;  
            case 's'
                canSpeedY=vBuiltIn;
                canSpeedX=0;
        end
        
    end
    

end